//
//  EducationTaskExtensions.swift
//  bsuirSchedule
//
//  Created by Andrej Hurynovič on 11.05.23.
//

import Foundation 

extension EducationTask: Identifiable { }

