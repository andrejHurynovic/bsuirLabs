//
//  EducationTypeExtensions.swift
//  bsuirSchedule
//
//  Created by Andrej Hurynovič on 1.05.23.
//

import Foundation

extension EducationType : Identifiable {}
