//
//  PrimaryScheduleViewState.swift
//  bsuirSchedule
//
//  Created by Andrej Hurynovič on 9.05.23.
//

enum PrimaryScheduleViewState {
    case updating
    case showLesson
    case noClosestSection
}
