//
//  DepartmentDecodingError.swift
//  bsuirSchedule
//
//  Created by Andrej Hurynovič on 1.05.23.
//

import Foundation

enum DepartmentDecodingError: Error {
    case noKeys
}
