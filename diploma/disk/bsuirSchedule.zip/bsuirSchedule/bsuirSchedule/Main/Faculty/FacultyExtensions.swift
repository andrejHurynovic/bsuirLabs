//
//  FacultyExtensions.swift
//  bsuirSchedule
//
//  Created by Andrej Hurynovič on 5.05.23.
//

extension Faculty : Identifiable {}
