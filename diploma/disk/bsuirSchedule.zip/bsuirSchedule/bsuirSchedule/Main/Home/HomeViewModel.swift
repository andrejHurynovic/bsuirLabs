////
////  HomeViewModel.swift
////  bsuirSchedule
////
////  Created by Andrej Hurynovič on 10.05.23.
////
//
//import SwiftUI
//
//class HomeViewModel: ObservableObject {
//     
//}
//
